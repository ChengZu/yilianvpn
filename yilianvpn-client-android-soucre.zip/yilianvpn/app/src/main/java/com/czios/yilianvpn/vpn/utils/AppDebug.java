package com.czios.yilianvpn.vpn.utils;

public class AppDebug {

    public static final boolean IS_DEBUG = true;

}
