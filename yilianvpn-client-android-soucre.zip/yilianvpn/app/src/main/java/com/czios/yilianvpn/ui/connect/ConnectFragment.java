package com.czios.yilianvpn.ui.connect;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;


import com.czios.yilianvpn.R;
import com.czios.yilianvpn.databinding.FragmentConnectBinding;
import com.czios.yilianvpn.ui.serverinfo.ServerInfoFragment;
import com.czios.yilianvpn.vpn.service.VpnService;
import com.czios.yilianvpn.vpn.utils.ProxyConfig;
import com.czios.yilianvpn.vpn.utils.VpnServiceHelper;

public class ConnectFragment extends Fragment {

    private FragmentConnectBinding binding;
    private View root;
    private Handler handler = new Handler();

    private TextView infoMsg;
    private TextView errorMsg;
    private Button startRun;
    private Button stopRun;
    private static boolean isRunning = false;
    private static boolean onStart = false;
    private static boolean onStop = false;

    public static final String myPref ="vpnOptions";
    ProxyConfig.VpnStatusListener vpnStatusListener = new ProxyConfig.VpnStatusListener() {
        @Override
        public void onVpnStart(Context context) {
            handler.post(() -> {
                        isRunning = true;
                        onStart = false;
                        onStop = false;
                        updateUI();
                        System.out.println("vpn start");
                    }
            );
        }

        @Override
        public void onVpnEnd(Context context) {
            handler.post(() -> {
                        isRunning = false;
                        onStart = false;
                        onStop = false;
                        updateUI();
                        System.out.println("vpn stop");
                    }
            );
        }
    };

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ConnectViewModel connectViewModel =
                new ViewModelProvider(this).get(ConnectViewModel.class);

        binding = FragmentConnectBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        infoMsg = binding.infoMsg;
        errorMsg = binding.errorMsg;
        startRun = binding.startRun;
        stopRun = binding.stopRun;
        //connectViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);


        if(!getPreferenceValue("ip").equals("0")){
            ProxyConfig.serverIp= getPreferenceValue("ip");
            ProxyConfig.serverPort = Integer.parseInt(getPreferenceValue("port"));
            ProxyConfig.userName= Integer.parseInt(getPreferenceValue("username"));
            ProxyConfig.userPwd = Integer.parseInt(getPreferenceValue("user-password"));
            ProxyConfig.DNS_FIRST = getPreferenceValue("dns1");
            ProxyConfig.DNS_SECOND = getPreferenceValue("dns2");
        }

        startRun.setOnClickListener(view -> {
            VpnService.errorMsg = "";
            if(!isRunning && !onStart){
                if(getPreferenceValue("new-install").equals("0")){
                    writeToPreference("new-install", "no");
                    startVPN();
                    closeVpn();
                    VpnService.errorMsg = getString(R.string.please_reconnect);
                }else{
                    onStart = true;
                    startVPN();
                }
                updateUI();
            }
        });
        stopRun.setOnClickListener(view -> {
            if(isRunning && !onStop){
                onStop = true;
                closeVpn();
                updateUI();
            }
        });
        ProxyConfig.Instance.cleanVpnStatusListener();
        ProxyConfig.Instance.registerVpnStatusListener(vpnStatusListener);
        updateUI();
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void updateUI() {
        if(onStart){
            startRun.setVisibility(View.VISIBLE);
            stopRun.setVisibility(View.INVISIBLE);
            infoMsg.setText(getString(R.string.connecting));
        }else if(onStop){
            startRun.setVisibility(View.INVISIBLE);
            stopRun.setVisibility(View.VISIBLE);
            infoMsg.setText(getString(R.string.disconnecting));
        }else if (VpnServiceHelper.vpnRunningStatus()){
            startRun.setVisibility(View.INVISIBLE);
            stopRun.setVisibility(View.VISIBLE);
            infoMsg.setText(String.format("%s%s:%d", getString(R.string.connected), ProxyConfig.serverIp, ProxyConfig.serverPort));
        }else if(!VpnServiceHelper.vpnRunningStatus()){
            startRun.setVisibility(View.VISIBLE);
            stopRun.setVisibility(View.INVISIBLE);
            infoMsg.setText(String.format("%s%s:%d", getString(R.string.not_connect), ProxyConfig.serverIp, ProxyConfig.serverPort));
        }
        String msg = "";
        String error = VpnService.errorMsg;
        if (VpnService.errorMsg.length() > 0) {
            msg = getString(R.string.error_msg) + error;
        }
        errorMsg.setText(msg);
    }

    private void startVPN() {
        if (!VpnServiceHelper.vpnRunningStatus()) {
            VpnServiceHelper.changeVpnRunningStatus(this.getContext(), true);
        }
    }

    private void closeVpn() {
        if (VpnServiceHelper.vpnRunningStatus()) {
            VpnServiceHelper.changeVpnRunningStatus(this.getContext(), false);
        }
    }

    public String getPreferenceValue(String key)
    {
        SharedPreferences sp = root.getContext().getSharedPreferences(myPref,0);
        return sp.getString(key,"0");
    }

    public void writeToPreference(String key, String value)
    {
        SharedPreferences.Editor editor = root.getContext().getSharedPreferences(myPref,0).edit();
        editor.putString(key, value);
        editor.apply();
    }
}