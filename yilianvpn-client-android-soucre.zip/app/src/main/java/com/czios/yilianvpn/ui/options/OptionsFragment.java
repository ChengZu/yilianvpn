package com.czios.yilianvpn.ui.options;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.czios.yilianvpn.R;
import com.czios.yilianvpn.databinding.FragmentOptionsBinding;
import com.czios.yilianvpn.vpn.httpProxy.ProxyHttpsServer;
import com.czios.yilianvpn.vpn.utils.ProxyConfig;
import com.czios.yilianvpn.vpn.utils.VpnServiceHelper;

public class OptionsFragment extends Fragment {

    private View root;
    public static final String myPref ="vpnOptions";

    private FragmentOptionsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        OptionsViewModel optionsViewModel =
                new ViewModelProvider(this).get(OptionsViewModel.class);

        binding = FragmentOptionsBinding.inflate(inflater, container, false);
        root = binding.getRoot();
        Context ctx = root.getContext();
        //获取配置
        readOptins(ctx);



        optionsViewModel.update();
        optionsViewModel.getIp().observe(getViewLifecycleOwner(), binding.optionsIpValue::setText);
        optionsViewModel.getPort().observe(getViewLifecycleOwner(), binding.optionsPortValue::setText);
        optionsViewModel.getName().observe(getViewLifecycleOwner(), binding.optionsUserNameValue::setText);
        optionsViewModel.getPwd().observe(getViewLifecycleOwner(), binding.optionsUserPasswordValue::setText);
        optionsViewModel.getDns1().observe(getViewLifecycleOwner(), binding.optionsDns1Value::setText);
        optionsViewModel.getDns2().observe(getViewLifecycleOwner(), binding.optionsDns2Value::setText);
        optionsViewModel.getProxyPort().observe(getViewLifecycleOwner(), binding.optionsHttpProxyPortValue::setText);
        binding.optionsRunHttpProxy.setChecked((ProxyConfig.RUN_HTTP_PROXY == 1) ? true : false);

        binding.optionsRunHttpProxy.setOnClickListener(view -> {
            ProxyConfig.RUN_HTTP_PROXY = binding.optionsRunHttpProxy.isChecked() ? 1 : 0;
            writeToPreference(ctx, "run_http_proxy", ProxyConfig.RUN_HTTP_PROXY + "");
        });

        binding.optionsSaveBtn.setOnClickListener(view -> {
            closeVpn();
            ProxyConfig.SERVER_IP = binding.optionsIpValue.getText().toString();
            ProxyConfig.SERVER_PORT = Integer.parseInt(binding.optionsPortValue.getText().toString());
            ProxyConfig.USER_NAME = Integer.parseInt(binding.optionsUserNameValue.getText().toString());
            ProxyConfig.USER_PWD = Integer.parseInt(binding.optionsUserPasswordValue.getText().toString());
            ProxyConfig.DNS_FIRST = binding.optionsDns1Value.getText().toString();
            ProxyConfig.DNS_SECOND = binding.optionsDns2Value.getText().toString();
            ProxyConfig.HTTP_PROXY_PORT = Integer.parseInt(binding.optionsHttpProxyPortValue.getText().toString());
            ProxyConfig.RUN_HTTP_PROXY = binding.optionsRunHttpProxy.isChecked() ? 1 : 0;

            writeOptins(ctx);
            showAlertDialog(getString(R.string.apply_success));
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void closeVpn() {
        if (VpnServiceHelper.vpnRunningStatus()) {
            VpnServiceHelper.changeVpnRunningStatus(this.getContext(), false);
        }
    }

    private void showAlertDialog(String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(root.getContext()).setIcon(R.mipmap.ic_launcher).setTitle(getString(R.string.result))
                .setMessage(msg).setPositiveButton(getString(R.string.ok), (dialogInterface, i) -> {
                    //Toast.makeText(root.getContext(), "成功！", Toast.LENGTH_SHORT).show();
                });
        builder.create().show();
    }

    public static  void readOptins(Context ctx){
        if(!getPreferenceValue(ctx, "ip").equals("0")){
            ProxyConfig.SERVER_IP= getPreferenceValue(ctx, "ip");
            ProxyConfig.SERVER_PORT = Integer.parseInt(getPreferenceValue(ctx, "port"));
            ProxyConfig.USER_NAME = Integer.parseInt(getPreferenceValue(ctx, "username"));
            ProxyConfig.USER_PWD = Integer.parseInt(getPreferenceValue(ctx, "user-password"));
            ProxyConfig.DNS_FIRST = getPreferenceValue(ctx, "dns1");
            ProxyConfig.DNS_SECOND = getPreferenceValue(ctx, "dns2");
            ProxyConfig.HTTP_PROXY_PORT = Integer.parseInt(getPreferenceValue(ctx, "http_proxy_port"));
            ProxyConfig.RUN_HTTP_PROXY = Integer.parseInt(getPreferenceValue(ctx, "run_http_proxy"));
        }
    }

    public static  void writeOptins(Context ctx){
        writeToPreference(ctx, "ip", ProxyConfig.SERVER_IP);
        writeToPreference(ctx, "port", ProxyConfig.SERVER_PORT + "");
        writeToPreference(ctx, "username", ProxyConfig.USER_NAME + "");
        writeToPreference(ctx, "user-password", ProxyConfig.USER_PWD + "");
        writeToPreference(ctx, "dns1", ProxyConfig.DNS_FIRST);
        writeToPreference(ctx, "dns2", ProxyConfig.DNS_SECOND);
        writeToPreference(ctx, "http_proxy_port", ProxyConfig.HTTP_PROXY_PORT + "");
        writeToPreference(ctx, "run_http_proxy", ProxyConfig.RUN_HTTP_PROXY + "");
    }
    public static String getPreferenceValue(Context ctx,String key)
    {
        SharedPreferences sp = ctx.getSharedPreferences(OptionsFragment.myPref,0);
        return sp.getString(key,"0");
    }

    public static void writeToPreference(Context ctx, String key, String value)
    {
        SharedPreferences.Editor editor = ctx.getSharedPreferences(OptionsFragment.myPref,0).edit();
        editor.putString(key, value);
        editor.apply();
    }
}