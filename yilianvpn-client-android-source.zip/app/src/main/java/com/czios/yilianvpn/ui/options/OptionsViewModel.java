package com.czios.yilianvpn.ui.options;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.czios.yilianvpn.vpn.utils.ProxyConfig;

public class OptionsViewModel extends ViewModel {

    private final MutableLiveData<String> mIp;
    private final MutableLiveData<String> mPort;
    private final MutableLiveData<String> mName;
    private final MutableLiveData<String> mPwd;
    private final MutableLiveData<String> mDns1;
    private final MutableLiveData<String> mDns2;

    public OptionsViewModel() {
        mIp = new MutableLiveData<>();
        mPort = new MutableLiveData<>();
        mName = new MutableLiveData<>();
        mPwd = new MutableLiveData<>();
        mDns1 = new MutableLiveData<>();
        mDns2 = new MutableLiveData<>();
        update();
    }

    public void update(){
        mIp.setValue(ProxyConfig.serverIp);
        mPort.setValue(ProxyConfig.serverPort + "");
        mName.setValue(ProxyConfig.userName + "");
        mPwd.setValue(ProxyConfig.userPwd + "");
        mDns1.setValue(ProxyConfig.DNS_FIRST);
        mDns2.setValue(ProxyConfig.DNS_SECOND);
    }
    public LiveData<String> getIp() {
        return mIp;
    }
    public LiveData<String> getPort() {
        return mPort;
    }
    public LiveData<String> getName() {
        return mName;
    }
    public LiveData<String> getPwd() {
        return mPwd;
    }
    public LiveData<String> getDns1() {
        return mDns1;
    }
    public LiveData<String> getDns2() {
        return mDns2;
    }

}