package com.czios.yilianvpn.ui.options;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.czios.yilianvpn.R;
import com.czios.yilianvpn.databinding.FragmentOptionsBinding;
import com.czios.yilianvpn.vpn.utils.ProxyConfig;
import com.czios.yilianvpn.vpn.utils.VpnServiceHelper;

public class OptionsFragment extends Fragment {

    private View root;
    public static final String myPref ="vpnOptions";

    private FragmentOptionsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        OptionsViewModel optionsViewModel =
                new ViewModelProvider(this).get(OptionsViewModel.class);

        binding = FragmentOptionsBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        //获取配置
        if(!getPreferenceValue("ip").equals("0")){
            ProxyConfig.serverIp= getPreferenceValue("ip");
            ProxyConfig.serverPort = Integer.parseInt(getPreferenceValue("port"));
            ProxyConfig.userName= Integer.parseInt(getPreferenceValue("username"));
            ProxyConfig.userPwd = Integer.parseInt(getPreferenceValue("user-password"));
            ProxyConfig.DNS_FIRST = getPreferenceValue("dns1");
            ProxyConfig.DNS_SECOND = getPreferenceValue("dns2");
        }

        optionsViewModel.update();
        optionsViewModel.getIp().observe(getViewLifecycleOwner(), binding.optionsIpValue::setText);
        optionsViewModel.getPort().observe(getViewLifecycleOwner(), binding.optionsPortValue::setText);
        optionsViewModel.getName().observe(getViewLifecycleOwner(), binding.optionsUserNameValue::setText);
        optionsViewModel.getPwd().observe(getViewLifecycleOwner(), binding.optionsUserPasswordValue::setText);
        optionsViewModel.getDns1().observe(getViewLifecycleOwner(), binding.optionsDns1Value::setText);
        optionsViewModel.getDns2().observe(getViewLifecycleOwner(), binding.optionsDns2Value::setText);

        binding.optionsSaveBtn.setOnClickListener(view -> {
            closeVpn();
            ProxyConfig.serverIp= binding.optionsIpValue.getText().toString();
            ProxyConfig.serverPort = Integer.parseInt(binding.optionsPortValue.getText().toString());
            ProxyConfig.userName= Integer.parseInt(binding.optionsUserNameValue.getText().toString());
            ProxyConfig.userPwd = Integer.parseInt(binding.optionsUserPasswordValue.getText().toString());
            ProxyConfig.DNS_FIRST = binding.optionsDns1Value.getText().toString();
            ProxyConfig.DNS_SECOND = binding.optionsDns2Value.getText().toString();

            writeToPreference("ip", ProxyConfig.serverIp);
            writeToPreference("port", ProxyConfig.serverPort + "");
            writeToPreference("username", ProxyConfig.userName + "");
            writeToPreference("user-password", ProxyConfig.userPwd + "");
            writeToPreference("dns1", ProxyConfig.DNS_FIRST);
            writeToPreference("dns2", ProxyConfig.DNS_SECOND);
            showAlertDialog(getString(R.string.apply_success));
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void closeVpn() {
        if (VpnServiceHelper.vpnRunningStatus()) {
            VpnServiceHelper.changeVpnRunningStatus(this.getContext(), false);
        }
    }

    private void showAlertDialog(String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(root.getContext()).setIcon(R.mipmap.ic_launcher).setTitle(getString(R.string.result))
                .setMessage(msg).setPositiveButton(getString(R.string.ok), (dialogInterface, i) -> {
                    //Toast.makeText(root.getContext(), "成功！", Toast.LENGTH_SHORT).show();
                });
        builder.create().show();
    }

    public String getPreferenceValue(String key)
    {
        SharedPreferences sp = root.getContext().getSharedPreferences(myPref,0);
        return sp.getString(key,"0");
    }

    public void writeToPreference(String key, String value)
    {
        SharedPreferences.Editor editor = root.getContext().getSharedPreferences(myPref,0).edit();
        editor.putString(key, value);
        editor.apply();
    }
}