package com.vcvnc.vpn.tunnel;

import com.vcvnc.vpn.utils.ProxyConfig;
import com.vcvnc.vpn.service.VpnService;
import com.vcvnc.vpn.tcpip.IPHeader;
import com.vcvnc.vpn.utils.DebugLog;

import java.io.IOException;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import com.vcvnc.xiguavpn.R;


public class RemoteTunnel implements Runnable {
    private static final String TAG = RemoteTunnel.class.getSimpleName();
    private final VpnService vpnService;
    private SocketChannel socketChannel;
    private boolean closed = false;
    private byte[] cacheBytes = new byte[ProxyConfig.MUTE * 2];
    private int cacheBytesSize = 0;
    private Thread thread = null;
    private String ipAndPort;

    private int maxProxyNum = 0;
    private int tcpProxyNum = 0;
    private int udpProxyNum = 0;


    public RemoteTunnel(VpnService vpnService) {
        this.vpnService = vpnService;
    }

    public void start() {
        connectServer();
        thread = new Thread(this, TAG);
        thread.start();
    }

    public void connectServer() {
        ipAndPort = ProxyConfig.serverIp + ":" + ProxyConfig.serverPort;
        DebugLog.iWithTag(TAG, "RemoteTunnel:%s connecting server.", ipAndPort);

        try {
            socketChannel = SocketChannel.open();
            socketChannel.configureBlocking(false);
            socketChannel.connect(new InetSocketAddress(ProxyConfig.serverIp, ProxyConfig.serverPort));
            vpnService.protect(socketChannel.socket());

            while (!socketChannel.finishConnect()) {
                Thread.sleep(1);
            }

            closed = false;
            //发送用户信息
            byte[] header = new byte[IPHeader.IP4_HEADER_SIZE];
            IPHeader ipheader = new IPHeader(header, 0);
            ipheader.setHeaderLength(IPHeader.IP4_HEADER_SIZE);
            ipheader.setTotalLength((short) IPHeader.IP4_HEADER_SIZE);
            ipheader.setSourceIP(ProxyConfig.userName);
            ipheader.setDestinationIP(ProxyConfig.userPwd);
            ipheader.setFlagsAndOffset((short) 1000);
            ipheader.setProtocol(ProxyConfig.CTRL);
            socketChannel.write(ByteBuffer.wrap(header, 0, IPHeader.IP4_HEADER_SIZE));
            DebugLog.iWithTag(TAG, "RemoteTunnel:%s connect server succeed.", ipAndPort);

        } catch (IOException e) {
            DebugLog.dWithTag(TAG, "RemoteTunnel:%s connect server fail.", ipAndPort);
            close(vpnService.getString(R.string.can_not_connect_server));
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void sendCtrlPacket(short code) {
        //发送用户信息
        byte[] header = new byte[IPHeader.IP4_HEADER_SIZE];
        IPHeader ipheader = new IPHeader(header, 0);
        ipheader.setHeaderLength(IPHeader.IP4_HEADER_SIZE);
        ipheader.setTotalLength((short) IPHeader.IP4_HEADER_SIZE);
        ipheader.setSourceIP(ProxyConfig.userName);
        ipheader.setDestinationIP(ProxyConfig.userPwd);
        ipheader.setFlagsAndOffset(code);
        ipheader.setProtocol(ProxyConfig.CTRL);
        try {
            socketChannel.write(ByteBuffer.wrap(header, 0, IPHeader.IP4_HEADER_SIZE));
        } catch (IOException e) {
            DebugLog.wWithTag(TAG, "Network write error: %s %s", ipAndPort, e);
            close(vpnService.getString(R.string.send_packet_error));
        }
    }

    //发送给服务器
    public void processPacket(byte[] bytes, int size) {
        try {
            socketChannel.write(ByteBuffer.wrap(bytes, 0, size));
        } catch (IOException e) {
            DebugLog.wWithTag(TAG, "Network write error: %s %s", ipAndPort, e);
            close(vpnService.getString(R.string.send_packet_error));
        }
    }

    public void close(String errMsg) {
        if (closed) return;
        closed = true;
        ProxyConfig.errorMsg = errMsg;
        vpnService.setVpnRunningStatus(false);
        if (thread != null)
            thread.interrupt();
        try {
            socketChannel.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean isClose() {
        return closed;
    }

    public void processCTRLPacket(byte[] packet, int offset, int size){
        IPHeader ipHeader = new IPHeader(packet, offset);
        maxProxyNum = ipHeader.getFlagsAndOffset();
        int code = ipHeader.getIdentification();
        if(code == 1000){
            int state = ipHeader.getSourceIP();
            if(state == 200){
                //String msg = vpnService.getString(R.string.user_verify_succeed);
            }else if(state == 403){
                close(vpnService.getString(R.string.user_verify_fail));
            }else{
                close(vpnService.getString(R.string.user_verify_succeed) + "code:" + state);
            }
        }else if(code == 1001){
            tcpProxyNum = ipHeader.getSourceIP();
            udpProxyNum = ipHeader.getDestinationIP();
        }
    }

    public void processRecvPacket(byte[] packet, int offset, int size) {
        IPHeader ipHeader = new IPHeader(packet, offset);

        byte protocol = ipHeader.getProtocol();
        if (protocol == IPHeader.TCP) {
            vpnService.write(packet, offset, size);
        } else if (protocol == IPHeader.UDP) {
            vpnService.write(packet, offset, size);
        } else if (protocol == ProxyConfig.CTRL) {
            processCTRLPacket(packet, offset, size);
        } else {
            DebugLog.dWithTag(TAG, "RemoteTunnel:%s rev unknown protocol packet.", ipAndPort);
            return;
        }
    }

    synchronized public void processRecvBuffer(byte[] bytes, int offset, int size) {
        if (cacheBytesSize > 0) {
            System.arraycopy(bytes, offset, cacheBytes, cacheBytesSize, size);
            size = cacheBytesSize + size;
            cacheBytesSize = 0;
            processRecvBuffer(cacheBytes, 0, size);
            return;
        }
        if (size < IPHeader.IP4_HEADER_SIZE) {
            System.arraycopy(bytes, offset, cacheBytes, 0, size);
            cacheBytesSize = size;
            return;
        }

        IPHeader IpHeader = new IPHeader(bytes, offset);
        int totalLength = IpHeader.getTotalLength();
        if (totalLength <= 0 || totalLength > ProxyConfig.MUTE) {
            close(vpnService.getString(R.string.rev_bad_length_packet));
            return;
        }
        if (totalLength < size) {
            processRecvPacket(bytes, offset, totalLength);
            int nextDataSize = size - totalLength;
            processRecvBuffer(bytes, (offset + totalLength), nextDataSize);
        } else if (totalLength == size) {
            processRecvPacket(bytes, offset, size);
        } else {
            System.arraycopy(bytes, offset, cacheBytes, 0, size);
            cacheBytesSize = size;
        }
    }


    @Override
    public void run() {
        try {
            int size = 0;
            byte[] bytes = new byte[ProxyConfig.MUTE];
            while (size != -1 && socketChannel.isOpen() && !closed) {
                size = socketChannel.read(ByteBuffer.wrap(bytes));
                if (size > 0) {
                    processRecvBuffer(bytes, 0, size);
                }
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        close(vpnService.getString(R.string.connect_closed));
    }

    public int getMaxProxyNum(){
        return maxProxyNum;
    }

    public int getTcpProxyNum(){
        return tcpProxyNum;
    }

    public int getUdpProxyNum(){
        return udpProxyNum;
    }
}
