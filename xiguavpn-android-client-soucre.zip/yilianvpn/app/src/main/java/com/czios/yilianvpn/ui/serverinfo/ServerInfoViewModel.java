package com.czios.yilianvpn.ui.serverinfo;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ServerInfoViewModel extends ViewModel {

    private final MutableLiveData<String> mServerInfo;

    public ServerInfoViewModel() {
        mServerInfo = new MutableLiveData<>();
        mServerInfo.setValue("服务器信息");
    }

    public LiveData<String> getServerInfo() {
        return mServerInfo;
    }
}