package com.czios.yilianvpn.ui.serverinfo;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.czios.yilianvpn.R;
import com.czios.yilianvpn.databinding.FragmentServerinfoBinding;
import com.czios.yilianvpn.vpn.tunnel.RemoteTunnel;
import com.czios.yilianvpn.vpn.utils.VpnServiceHelper;

public class ServerInfoFragment extends Fragment {

    private View root;
    private TextView server_info;
    private TextView max_proxy_num;
    private TextView tcp_proxy_num;
    private TextView udp_proxy_num;
    private GetInfoTask getInfoTask = null;
    private FragmentServerinfoBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ServerInfoViewModel serverInfoViewModel =
                new ViewModelProvider(this).get(ServerInfoViewModel.class);

        binding = FragmentServerinfoBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        server_info = root.findViewById(R.id.server_info);
        max_proxy_num = root.findViewById(R.id.server_info_max_proxy_num);
        tcp_proxy_num = root.findViewById(R.id.server_info_tcp_proxy_num);
        udp_proxy_num = root.findViewById(R.id.server_info_udp_proxy_num);

        server_info.setText(root.getContext().getString(R.string.server_info_note));

        // 启动任务
        getInfoTask = new GetInfoTask();
        getInfoTask.execute("arg");
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        if(getInfoTask != null){
            getInfoTask.cancel(true);
            getInfoTask = null;
        }
    }

    public class GetInfoTask extends AsyncTask<String, Integer, String> {

        @Override
        protected void onPreExecute() {
            // 显示进度条
            udp_proxy_num.setText("");
            tcp_proxy_num.setText("");
            if (VpnServiceHelper.vpnRunningStatus()) {
                max_proxy_num.setText(root.getContext().getString(R.string.on_update));
            } else {
                max_proxy_num.setText(root.getContext().getString(R.string.vpn_is_closed_need_run_get_info));
            }
        }

        @Override
        protected String doInBackground(String... urls) {
            String url = urls[0];
            int totalSize = 5 * 60;
            for (int i = 1; i <= totalSize; i++) {
                // 模拟下载耗时
                VpnServiceHelper.sendCtrlPacket((short) 1001);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    break;
                }
                RemoteTunnel tunnel = VpnServiceHelper.getRemoteTunnel();
                if (tunnel != null) {
                    max_proxy_num.setText(root.getContext().getString(R.string.max_proxy_num) + tunnel.getMaxProxyNum());
                    tcp_proxy_num.setText(root.getContext().getString(R.string.tcp_proxy_num) + tunnel.getTcpProxyNum());
                    udp_proxy_num.setText(root.getContext().getString(R.string.udp_proxy_num) + tunnel.getUdpProxyNum());
                } else {
                    max_proxy_num.setText(root.getContext().getString(R.string.vpn_is_closed_need_run_get_info));
                    tcp_proxy_num.setText("");
                    udp_proxy_num.setText("");
                }
                // 发布进度
                publishProgress(i);
                // 检查是否被取消
                if (isCancelled()) {
                    return "已取消";
                }
            }
            return "下载完成: " + url;
        }

        @Override
        protected void onProgressUpdate(Integer... progress) {
            // 更新进度条
        }

        @Override
        protected void onPostExecute(String result) {
            // 隐藏进度条，显示结果
            max_proxy_num.setText(root.getContext().getString(R.string.on_stop_update_server_info));
            tcp_proxy_num.setText("");
            udp_proxy_num.setText("");
        }

        @Override
        protected void onCancelled() {
            //Toast.makeText(root.getContext(), "更新被取消", Toast.LENGTH_SHORT).show();
        }
    }
}