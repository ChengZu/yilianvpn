package com.czios.yilianvpn.vpn.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.czios.yilianvpn.vpn.service.VpnService;
import com.czios.yilianvpn.vpn.tunnel.RemoteTunnel;

public class VpnServiceHelper {
    private static Context context;
    public static final int START_VPN_SERVICE_REQUEST_CODE = 1;
    private static VpnService sVpnService = null;

    public static void onVpnServiceCreated(VpnService vpnService) {
        sVpnService = vpnService;
        if(context==null){
            context=vpnService.getApplicationContext();
        }
    }

    public static void onVpnServiceDestroy() {
        sVpnService = null;
    }


    public static Context getContext() {
        return context;
    }
    public static VpnService getVpnService() {
        return sVpnService;
    }

    public static boolean vpnRunningStatus() {
        if (sVpnService != null) {
            return sVpnService.vpnRunningStatus();
        }
        return false;
    }

    public static void changeVpnRunningStatus(Context context, boolean isStart) {
        if (context == null) {
            return;
        }
        if(sVpnService != null){
            sVpnService.errorMsg = "";
        }
        if (isStart) {
            Intent intent = VpnService.prepare(context);
            if (intent == null) {
                startVpnService(context);
            } else {
                if (context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, START_VPN_SERVICE_REQUEST_CODE);
                }
            }
        } else if (sVpnService != null) {
            boolean stopStatus = false;
            sVpnService.setVpnRunningStatus(stopStatus);
        }
    }

    public static void startVpnService(Context context) {
        if (context == null) {
            return;
        }
        context.startService(new Intent(context, VpnService.class));
    }

    public static void sendCtrlPacket(short code) {
        if (sVpnService != null) {
            sVpnService.sendCtrlPacket(code);
        }
    }

    public static RemoteTunnel getRemoteTunnel() {
        if (sVpnService != null) {
            return sVpnService.getRemoteTunnel();
        }
        return null;
    }
}
