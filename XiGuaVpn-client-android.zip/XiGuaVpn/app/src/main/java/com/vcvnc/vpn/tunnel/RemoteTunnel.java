package com.vcvnc.vpn.tunnel;

import com.vcvnc.vpn.utils.ProxyConfig;
import com.vcvnc.vpn.service.VpnService;
import com.vcvnc.vpn.tcpip.IPHeader;
import com.vcvnc.vpn.utils.DebugLog;

import java.io.IOException;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import com.vcvnc.xiguavpn.R;


public class RemoteTunnel implements Runnable {
    private static final String TAG = RemoteTunnel.class.getSimpleName();
    private final VpnService vpnService;
    private SocketChannel socketChannel;
    private boolean closed = false;
    private byte[] cacheBytes = new byte[ProxyConfig.MUTE * 2];
    private int cacheBytesSize = 0;
    Thread thread = null;
    String ipAndPort;
    public RemoteTunnel(VpnService vpnService) {
        this.vpnService = vpnService;
    }

    public void start() {
        connectServer();
        thread = new Thread(this, TAG);
        thread.start();
    }

    public void connectServer() {
        ipAndPort = ProxyConfig.serverIp+":"+ProxyConfig.serverPort;
        DebugLog.iWithTag(TAG, "RemoteTunnel:%s connecting server.", ipAndPort);

        try {
            socketChannel = SocketChannel.open();
            socketChannel.configureBlocking(false);
            socketChannel.connect(new InetSocketAddress(ProxyConfig.serverIp, ProxyConfig.serverPort));
            vpnService.protect(socketChannel.socket());

            while (!socketChannel.finishConnect()){
                Thread.sleep(1);
            }

            closed = false;
            //发送用户信息
            byte[] header = new byte[IPHeader.IP4_HEADER_SIZE];
            IPHeader ipheader = new IPHeader(header, 0);
            ipheader.setHeaderLength(IPHeader.IP4_HEADER_SIZE);
            ipheader.setSourceIP(ProxyConfig.userName);
            ipheader.setDestinationIP(ProxyConfig.userPwd);
            ipheader.setProtocol((byte) IPHeader.TCP);
            socketChannel.write(ByteBuffer.wrap(header, 0, IPHeader.IP4_HEADER_SIZE));
            DebugLog.iWithTag(TAG, "RemoteTunnel:%s connect server succeed.", ipAndPort);

        } catch (IOException e) {
            DebugLog.dWithTag(TAG, "RemoteTunnel:%s connect server fail.", ipAndPort);
            close(vpnService.getString(R.string.can_not_connect_server));
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    //发送给服务器
    public void processPacket(byte[] bytes, int size) {
        try {
            socketChannel.write(ByteBuffer.wrap(bytes, 0, size));
        } catch (IOException e) {
            DebugLog.wWithTag(TAG, "Network write error: %s %s", ipAndPort, e);
            close(vpnService.getString(R.string.send_packet_error));
        }
    }

    public void close(String errMsg) {
        if(closed) return;
        closed = true;
        ProxyConfig.errorMsg = errMsg;
        vpnService.setVpnRunningStatus(false);
        if(thread != null)
            thread.interrupt();
        try {
            socketChannel.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean isClose() {
        return closed;
    }

    synchronized public void processRecvPacket(byte[] bytes, int offset, int size) {
        if(cacheBytesSize > 0) {
            System.arraycopy(bytes, offset, cacheBytes, cacheBytesSize, size);
            size = cacheBytesSize + size;
            cacheBytesSize = 0;
            processRecvPacket(cacheBytes, 0, size);
            return;
        }
        if (size < IPHeader.IP4_HEADER_SIZE) {
            System.arraycopy(bytes, offset, cacheBytes, 0, size);
            cacheBytesSize = size;
            return;
        }

        IPHeader IpHeader = new IPHeader(bytes, offset);
        int totalLength = IpHeader.getTotalLength();
        if(totalLength <= 0 || totalLength > ProxyConfig.MUTE || size > (2 * ProxyConfig.MUTE)){
            close(vpnService.getString(R.string.rev_bad_length_packet));
            return;
        }
        if(totalLength < size){
            vpnService.write(bytes, offset, totalLength);
            int nextDataSize = size - totalLength;
            processRecvPacket(bytes, (offset + totalLength), nextDataSize);
        }else if(totalLength == size){
            vpnService.write(bytes, offset, size);
        }else{
            System.arraycopy(bytes, offset, cacheBytes, 0, size);
            cacheBytesSize = size;
        }
    }

    @Override
    public void run() {
        try {
            int size = 0;
            byte[] bytes = new byte[ProxyConfig.MUTE];
            while (size != -1 && socketChannel.isOpen() && !closed) {
                size = socketChannel.read(ByteBuffer.wrap(bytes));
                if (size > 0) {
                    processRecvPacket(bytes, 0, size);
                }
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        close(vpnService.getString(R.string.connect_closed));
    }

}
